#include <stdio.h>
#include <stdlib.h>

int vuln(){
	char buf[136];
	read(0, buf, 256);
}

int main(){
	write(1, "WELCOME TO ROP PRACTICE 101!\n", 30);
	vuln();
	write(1, "THANKS FOR PLAYING!\n", 30);
}
