#include <stdio.h>
#include <stdlib.h>

float greater(float x, float y){
  return x>y ? x : y;
}

float divvy(float x){
  x /= 15.5;
  return x;
}

int main(){
  float x,y,z;

  scanf("%f %f %f", &x,&y,&z);

  x = divvy(greater(x,y));

  if(x > 0.8 && x < 0.9){
    printf("WINNER\n");
  }

}
