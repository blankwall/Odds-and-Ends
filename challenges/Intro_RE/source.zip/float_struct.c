#include <stdio.h>
#include <stdlib.h>

int grades[] = { 90, 87, 69, 110, 100, 82, 85, 89, 91};

struct school_yard
{
    float grade;
    int grades;
    char *name;
    char is_student;
    void (*print_self)(struct school_yard*);
};

void print_student(struct school_yard* k){
  printf("I am a student with grade %f \n", k->grade*10);
}

void print_teacher(){
  printf("I am a teacher with no grade :P\n");
}

void calculate_grade(struct school_yard* k, int l){
  k->grades++;
  k->grade = (k->grade+l)/k->grades;
}

int main()
{
  struct school_yard a;
  int i;
  char k[] = "Tyler";
  a.name = k;
  a.is_student = 1;
  a.grades = 0;
  a.print_self = &print_student;
  a.print_self(&a);
  for(i = 0; i < sizeof(grades)/ sizeof(int); ++i){
    calculate_grade(&a, grades[i]);
    //printf("%d\n", i);
  }
  printf("What is my gpa?\n");
  int loo;
  scanf("%d", &loo);
  if(loo == a.grade){
    printf("Yay you solved it!\n");
  }
}
