#include <stdio.h>

int prime(int n)
{
   int c;

   if ( n == 2 )
     return 1;
   else
   {
       for ( c = 2 ; c <= n - 1 ; c++ )
       {
           if ( n % c == 0 )
              break;
       }
       if ( c != n )
          return 0;
       else
         return 1;
   }
   return 0;
}

int main(){
  int x;
  scanf("%d", &x);

  if(prime(x) && ((x > 1000) && (x < 1020)))
    printf("WINNER\n");
}
