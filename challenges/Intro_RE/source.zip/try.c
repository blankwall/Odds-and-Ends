#include <stdio.h>
#include <stdlib.h>
//k = 9312
#define array 100000
int x[array];

int change_value(int k){
  return ((((k >> 2) + 5) * 12) ^ 2);
}

int main(){
  int i;

  for(i = 0; i < array; ++i){
    x[i] = i;
  }

  int g = x[27998], k;

  scanf("%d", &k);

  k = change_value(k);

  if(k == g)
    printf("Winner\n");
}
