#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

struct node{
	struct node* next;
	char *buf;
	int code;
};

void print_list(struct node* head){
	while(head != NULL){
		printf("%s\n", head->buf);
		head = head->next;
	}
}
	
void copy(struct node* head, char* k){
	strcpy(head->buf, k);
}

struct node* add_link(int x){
	struct node* newb = malloc(sizeof(struct node));
	newb->next = NULL;
	newb->buf = malloc(100);
	newb->code = x;
	return newb;
}

int check_sequence(struct node* head){
	int x = 0, count = 0;
	while(1){
		if(x == 1542 && count >= 10){
			return 1;
		}
		if(x > 1992 || count > 15) { 
			return 0;
		}
		int k, i;
		printf("%d\n", x); 
		printf(" #: "); 
		scanf("%d", &k);
		struct node* temp = head;
		for(i = 0; i < k; ++i){
			temp = temp->next;
		}
		x += temp->code;
	}
}

void read_key(){
	int fd = open("key", O_RDONLY);
	char buf[199];
	fd = read(fd, buf, 199);
	buf[fd] = 0;
	write(1, buf, fd);
}

int main(){
	#include <time.h>
	time_t tim = time(NULL);
	printf("%ld\n", tim);
	srand(tim);

	struct node *head = add_link(9);
	char *k = "Welcome to the RE Door code challenge! This is going to be hard as fuck!\n";
	copy(head, k);
	printf("%s", head->buf);
	int x = 0;
	struct node* temp = head;
	while(x++ < 10000){
		int r = rand() % 100;
		temp->next = add_link(r);
		temp = temp->next;
		copy(temp, "\x52\x74\x34\x96");
	}
	char *j = "Input sequence\n";
	temp = head->next;
	copy(temp, j);
	printf("%s", temp->buf);

	int clear = check_sequence(head);
	if(!clear){
		printf("To bad!\n");
		return 0;
	}	
	printf("YOU WIN!");	
	read_key();
}
