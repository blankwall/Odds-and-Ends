#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int admin = 1;
char buf[1000];

int vuln_maybe(int loop){
	char buf[10];
	loop = loop&0xf0;
	if(loop != 0x40)
		return 0;
	return read(0, buf, 22);
}

int main(){
	char buf[10], *a;
	int x, y = read(0, buf, 9), subtle = 1;	
	buf[y-1] = 0;

	printf("Welcome %s to the bakery!\n", buf);
	write(1, "What size?\n", 11);	
	fflush(stdout);

	scanf("%d", &x);

	if(x > 0){	
		a = alloca(4*x);
		printf("Block Size: %d\n", 4*x);
	}	
	
	fflush(stdout);
	
	unsigned int k = 0;
	
	k = x;
	int loop = read(0, a, 4*k);
	buf[loop] = '0';
	printf("Baking block!\n");
	vuln_maybe(loop);
}	
